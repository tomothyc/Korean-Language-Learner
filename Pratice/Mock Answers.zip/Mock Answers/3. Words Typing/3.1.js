const vocab = [
    { kr: '오이', en: 'Cucumber'},
    { kr: '구두', en: 'Shoes'},
    { kr: '유리', en: 'Glass'},
    { kr: '누나', en: '(Older) Sister'},
    { kr: '여우', en: 'Fox'},
    { kr: '의미', en: 'Meaning'},
    { kr: '의자', en: 'Chair'},
    { kr: '바다', en: 'Sea'},
    { kr: '우유', en: 'Milk'},
    { kr: '의사', en: 'Doctor'}
  ];