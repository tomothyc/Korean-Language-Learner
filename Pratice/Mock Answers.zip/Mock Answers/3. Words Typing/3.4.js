const vocab = [
    { kr: '일요일', en: 'Sunday'},
    { kr: '자전거', en: 'Bicycle'},
    { kr: '금요일', en: 'Friday'},
    { kr: '까만색', en: 'Black'},
    { kr: '이집트', en: 'Egypt'},
    { kr: '똑바로', en: 'Straight'},
    { kr: '휴대폰', en: 'Mobile Phone'},
    { kr: '한식집', en: 'Korean Restaurant'},
    { kr: '선생님', en: 'Teacher'},
    { kr: '사장님', en: 'Boss'}
  ];