const vocab = [
    { kr: '비디오', en: 'Video'},
    { kr: '어머니', en: 'Mother'},
    { kr: '아버지', en: 'Father'},
    { kr: '추워요', en: 'Cold'},
    { kr: '바빠요', en: 'Busy'},
    { kr: '주사위', en: 'Dice'},
    { kr: '때때로', en: 'Seldom'},
    { kr: '쉬워요', en: 'Easy'},
    { kr: '더워요', en: 'Hot'},
    { kr: '예뻐요', en: 'Pretty'},
    { kr: '토마토', en: 'Tomato'}
  ];