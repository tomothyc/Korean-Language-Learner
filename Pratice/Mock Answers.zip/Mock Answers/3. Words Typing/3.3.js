const vocab = [
    { kr: '연휴', en: 'Long Weekend'},
    { kr: '남편', en: 'Husband'},
    { kr: '입술', en: 'Lips'},
    { kr: '전기', en: 'Electricity'},
    { kr: '유통', en: 'Distribution'},
    { kr: '사랑', en: 'Love'},
    { kr: '사람', en: 'People'},
    { kr: '공부', en: 'Study'},
    { kr: '눈물', en: 'Tear'},
    { kr: '택배', en: 'Delivery Service'}
  ];