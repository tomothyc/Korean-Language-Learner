const vocab = [
    { kr: '수진 씨 전화번호가 몇 번이에요?', en: "What is Sujin’s phone number?"},
    { kr: '시메이 씨가 한국어를 배워요.', en: 'Shimei learns Korean.'},
    { kr: '아침에 학생들이 수업을 들어요.', en: 'The students take their class in the morning.'},
    { kr: '토마스 씨는 여자 친구에게서 선물을 받았어요.', en: 'Thomas received a present from his girlfriend.'},
    { kr: '예린 팀장님이 월요일부터 금요일까지 일해요.', en: 'Ms Yerin works from Monday to Friday.'},
    { kr: '보통 일요일에 친구와 같이 등산해요.', en: 'Usually on Sunday I go hiking with my friends.'},
    { kr: '지호 씨는 어제 알바를 했어요. 그래서 많이 피곤해요.', en: 'Jiho worked part-time yesterday. So he is tired'},
    { kr: '커피숍은 도서관과 서점 사이에 있어요.', en: 'The coffee shop is between the library and the bookstore.'},
    { kr: '작년부터 한국어를 공부해요. 그런데 잘못 해요.', en: 'I have been studying Korean since last year. But I not very good.'},
    { kr: '사라 씨는 진난주말에 노래방에서 노래를 불렀어요.', en: 'Sara sang a song at the karaoke last weekend.'}
  ];