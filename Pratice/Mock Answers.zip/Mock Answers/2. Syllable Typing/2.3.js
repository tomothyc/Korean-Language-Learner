const vocab = [
    { kr: '별', en: 'Star'},
    { kr: '김', en: 'Algae'},
    { kr: '집', en: 'House'},
    { kr: '입', en: 'Mouth'},
    { kr: '번', en: 'Number'},
    { kr: '산', en: 'Mountain'},
    { kr: '강', en: 'River'},
    { kr: '힘', en: 'Strength'},
    { kr: '책', en: 'Book'},
    { kr: '것', en: 'Thing'}
  ];