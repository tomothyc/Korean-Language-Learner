const vocab = [
    { kr: '뺨', en: 'Cheek'},
    { kr: '떡', en: 'Rice Cake'},
    { kr: '땅', en: 'Land'},
    { kr: '빵', en: 'Bread'},
    { kr: '쌍', en: 'Couple, Pair'},
    { kr: '쌀', en: 'Rice'},
    { kr: '꿈', en: 'Dream'},
    { kr: '꽃', en: 'Flower'},
    { kr: '끝', en: 'End'},
    { kr: '딸', en: 'Daughter'}
  ];