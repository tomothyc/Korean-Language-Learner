const vocab = [
    { kr: '띠', en: ''},
    { kr: '빠', en: ''},
    { kr: '또', en: ''},
    { kr: '짜', en: ''},
    { kr: '쏘', en: ''},
    { kr: '뿌', en: ''},
    { kr: '씨', en: ''},
    { kr: '깨', en: ''},
    { kr: '꺼', en: ''},
    { kr: '쁘', en: ''}
  ];