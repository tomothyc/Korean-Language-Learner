const vocab = [
    { kr: '가', en: ''},
    { kr: '고', en: ''},
    { kr: '니', en: ''},
    { kr: '햐', en: ''},
    { kr: '추', en: ''},
    { kr: '파', en: ''},
    { kr: '두', en: ''},
    { kr: '세', en: ''},
    { kr: '타', en: ''},
    { kr: '무', en: ''}
  ];