const vocab = [
    { kr: '넋', en: 'Spirit'},
    { kr: '값', en: 'Price'},
    { kr: '닭', en: 'Chicken'},
    { kr: '흙', en: 'Soil'},
    { kr: '삶', en: 'Life'},
    { kr: '몫', en: 'Share'},
    { kr: '삯', en: 'Wage'},
    { kr: '칡', en: 'Kudzu'}
  ];