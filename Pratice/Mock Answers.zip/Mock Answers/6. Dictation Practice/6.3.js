const vocab = [
    { kr: '방학 때 전주에 가서 한옥마을을 구경할 거예요.', en: 'During the vacation I’ll go to Jeonju to see the Korean traditional village.'},
    { kr: '제주도에서 맛있는 삼겹살을 먹었어요.', en: 'I ate a yummy samgyepsal in Jeju.'},
    { kr: '보통 주말에 산책을 하거나 친구를 만나요.', en: 'Usually during the weekend I go for a walk or I meet my friends.'}
  ];