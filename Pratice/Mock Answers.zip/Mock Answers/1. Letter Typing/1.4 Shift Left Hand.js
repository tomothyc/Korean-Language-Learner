const vocab = [
    { kr: 'ㅃ', en: ''},
    { kr: 'ㅉ', en: ''},
    { kr: 'ㄸ', en: ''},
    { kr: 'ㄲ', en: ''},
    { kr: 'ㅆ', en: ''}
  ];