const vocab = [
    { kr: 'ㅒ', en: ''},
    { kr: 'ㅖ', en: ''}
  ];