const vocab = [
    { kr: '이름이 뭐예요?', en: "What’s your name?"},
    { kr: '어느 나라 사람이에요?', en: 'Where do you come from?'},
    { kr: '몇 살이에요?', en: 'How old are you?'},
    { kr: '저녁에 파티가 있어요.', en: 'There is a party tonight.'},
    { kr: '퍼스는 호주에 있어요.', en: 'Perth is in Australia.'},
    { kr: '학교에 학생이 많아요.', en: 'There are many students at school.'},
    { kr: '이분은 김 선생님이에요.', en: 'This person is Ms Kim.'},
    { kr: '일요일에 마트에 가요.', en: 'I go to the supermarket on Sunday.'},
    { kr: '호떡이 얼마예요?', en: 'How much is hotteok?'},
    { kr: '아이스 바닐라 라떼 주세요.', en: "Please give me an ice vanilla latte."}
  ];