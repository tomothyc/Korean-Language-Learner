const letters = [
  {
    english: "E"
  },
  {
    english: "A"
  },
  {
    english: "B"
  }
];
module.exports = letters;
