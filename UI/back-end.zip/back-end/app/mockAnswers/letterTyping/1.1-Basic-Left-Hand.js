const vocab = [
  { step: "letters", exercise: "Lhand", kr: "ㅂ", en: "a" },
  { step: "letters", exercise: "Lhand", kr: "ㅈ", en: "a" },
  { step: "letters", exercise: "Lhand", kr: "ㄷ", en: "a" },
  { step: "letters", exercise: "Lhand", kr: "ㄱ", en: "a" },
  { step: "letters", exercise: "Lhand", kr: "ㅅ", en: "a" },
  { step: "letters", exercise: "Lhand", kr: "ㅁ", en: "a" },
  { step: "letters", exercise: "Lhand", kr: "ㄴ", en: "a" },
  { step: "letters", exercise: "Lhand", kr: "ㅇ", en: "a" },
  { step: "letters", exercise: "Lhand", kr: "ㄹ", en: "a" },
  { step: "letters", exercise: "Lhand", kr: "ㅎ", en: "a" },
  { step: "letters", exercise: "Lhand", kr: "ㅋ", en: "a" },
  { step: "letters", exercise: "Lhand", kr: "ㅌ", en: "a" },
  { step: "letters", exercise: "Lhand", kr: "ㅊ", en: "a" },
  { step: "letters", exercise: "Lhand", kr: "ㅍ", en: "a" }
];

module.exports = vocab;
