const vocab = [
  { step: "letters", exercise: "SRhand", kr: "ㅒ", en: "a" },
  { step: "letters", exercise: "SRhand", kr: "ㅖ", en: "a" }
];
module.exports = vocab;
