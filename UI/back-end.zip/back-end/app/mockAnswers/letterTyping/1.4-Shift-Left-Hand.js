const vocab = [
  { step: "letters", exercise: "SLhand", kr: "ㅃ", en: "a" },
  { step: "letters", exercise: "SLhand", kr: "ㅉ", en: "a" },
  { step: "letters", exercise: "SLhand", kr: "ㄸ", en: "a" },
  { step: "letters", exercise: "SLhand", kr: "ㄲ", en: "a" },
  { step: "letters", exercise: "SLhand", kr: "ㅆ", en: "a" }
];
module.exports = vocab;
