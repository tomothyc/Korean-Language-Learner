const vocab = [
  { step: "letters", exercise: "Rhand", kr: "ㅛ", en: "a" },
  { step: "letters", exercise: "Rhand", kr: "ㅕ", en: "a" },
  { step: "letters", exercise: "Rhand", kr: "ㅑ", en: "a" },
  { step: "letters", exercise: "Rhand", kr: "ㅐ", en: "a" },
  { step: "letters", exercise: "Rhand", kr: "ㅔ", en: "a" },
  { step: "letters", exercise: "Rhand", kr: "ㅗ", en: "a" },
  { step: "letters", exercise: "Rhand", kr: "ㅓ", en: "a" },
  { step: "letters", exercise: "Rhand", kr: "ㅏ", en: "a" },
  { step: "letters", exercise: "Rhand", kr: "ㅣ", en: "a" },
  { step: "letters", exercise: "Rhand", kr: "ㅠ", en: "a" },
  { step: "letters", exercise: "Rhand", kr: "ㅜ", en: "a" },
  { step: "letters", exercise: "Rhand", kr: "ㅡ", en: "a" }
];
module.exports = vocab;
