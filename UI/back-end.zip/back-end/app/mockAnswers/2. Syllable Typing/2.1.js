const vocab = [
  { step: "syllables", exercise: "CV", kr: "가", en: "" },
  { step: "syllables", exercise: "CV", kr: "고", en: "" },
  { step: "syllables", exercise: "CV", kr: "니", en: "" },
  { step: "syllables", exercise: "CV", kr: "햐", en: "" },
  { step: "syllables", exercise: "CV", kr: "추", en: "" },
  { step: "syllables", exercise: "CV", kr: "파", en: "" },
  { step: "syllables", exercise: "CV", kr: "두", en: "" },
  { step: "syllables", exercise: "CV", kr: "세", en: "" },
  { step: "syllables", exercise: "CV", kr: "타", en: "" },
  { step: "syllables", exercise: "CV", kr: "무", en: "" }
];
