const vocab = [
  { step: "letters", exercise: "Rhand", kr: "띠", en: "" },
  { step: "letters", exercise: "Rhand", kr: "빠", en: "" },
  { step: "letters", exercise: "Rhand", kr: "또", en: "" },
  { step: "letters", exercise: "Rhand", kr: "짜", en: "" },
  { step: "letters", exercise: "Rhand", kr: "쏘", en: "" },
  { step: "letters", exercise: "Rhand", kr: "뿌", en: "" },
  { step: "letters", exercise: "Rhand", kr: "씨", en: "" },
  { step: "letters", exercise: "Rhand", kr: "깨", en: "" },
  { step: "letters", exercise: "Rhand", kr: "꺼", en: "" },
  { step: "letters", exercise: "Rhand", kr: "쁘", en: "" }
];
