const vocab = [
    { kr: '우리 나라', en: 'Our country (Korea)'},
    { kr: '어느 나라', en: 'Which country'},
    { kr: '엘리베이터', en: 'Elevator'},
    { kr: '스파케티', en: 'Spaghetti'},
    { kr: '자동판매기', en: 'Vending Machine'},
    { kr: '전화번호', en: 'Phone Number'},
    { kr: '반가워요', en: 'Glad'},
    { kr: '괜찮아요', en: 'Be ok, Fine'},
    { kr: '좋아해요', en: 'Like'},
    { kr: '싫어해요', en: "Don't Like"}
  ];