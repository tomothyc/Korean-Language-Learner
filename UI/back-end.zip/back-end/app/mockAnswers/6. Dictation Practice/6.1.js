const vocab = [
    { kr: '선생님', en: 'Teacher'},
    { kr: '회사원', en: 'Company Worker'},
    { kr: '이름', en: 'Name'},
    { kr: '맥주', en: 'Beer'}
  ];