const vocab = [
    { kr: '지호 씨는 한국 사람이에요.', en: 'Jiho is Korean.'},
    { kr: '보통 아침에 일곱 시에 일어나요.', en: 'Usually I wake up at seven in the morning.'},
    { kr: '사라 씨 전화번호가 몇 번이에요?', en: "What’s Sara’s phone number?"}
  ];