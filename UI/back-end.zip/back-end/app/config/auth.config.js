module.exports = {
  secret: "437813849321423fhfadksfljsdf38438249324jfdsjfjfjfkd8339"
};
